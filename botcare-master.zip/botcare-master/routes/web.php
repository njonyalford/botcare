<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function () {
    return view('begin');
});

Route::get('/faq',  function () {
    return view('Lesaviezvous');
});


Route::get('/help', function () {
    return view('help');
});


Route::get('/login', function () {
    return view('login');
});

Route::get('/statistic', function () {
    return view('statistic');
});

Route::match(['get', 'post'], '/botman', 'BotManController@handle');
Route::get('/botman/tinker', 'BotManController@tinker');


Route::get('/customers/pdf','CustomerController@export_pdf');