<?php

use App\Conversations\FriendlyConversation;
use App\Http\Controllers\BotManController;
use BotMan\BotMan\Messages\Incoming\Answer;

$botman = resolve('botman');


$botman->hears('Hi', function ($bot) {
    $bot->reply('Hello!');
});

$botman->hears('Hello', function($bot) {
    $bot->startConversation(new FriendlyConversation);
});


use BotMan\BotMan\Middleware\ApiAi;
$botman = resolve('botman');


$dialogflow = ApiAi::create('396998716380')->listenForAction();

// Apply global "received" middleware
$botman->middleware->received($dialogflow);

// Apply matching middleware per hears command
$botman->hears('askWhatYouDo', function (BotMan $bot) {
    // The incoming message matched the "my_api_action" on Dialogflow
    // Retrieve Dialogflow information:
    $extras = $bot->getMessage()->getExtras();
    $apiReply = $extras['apiReply'];
    $apiAction = $extras['apiAction'];
    $apiIntent = $extras['apiIntent'];
    
    $bot->reply($apiReply);
})->middleware($dialogflow);







