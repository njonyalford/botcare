<?php

namespace App\Conversations;
use BotMan\BotMan\Messages\Incoming\Answer;
use BotMan\BotMan\Messages\Outgoing\Question;
use BotMan\BotMan\Messages\Outgoing\Actions\Button;
use BotMan\BotMan\Messages\Conversations\Conversation;

class FriendlyConversation extends Conversation
{
    /**
     * Start the conversation.
     *
     * @return mixed
     */

    protected $user_name ; 
    protected $deja ; 

    public function askHelp()
    {
     

        if($this->deja == 1){
            $this->say("C'est parti pour un autre tour :) ".$this->user_name); 
        }
        
        $question_help = Question::create("Huh - How can I help ? 🤘")
            ->fallback("Am sorry. Seems like I dont understand.")
            ->callbackId('ask_help')
            ->addButtons([
                Button::create('Informations about the authors')->value('authors'),
                Button::create('About me')->value('botcare'),
                Button::create('Hepatitis informations')->value('hepatitis'),
            ]);

        return $this->ask($question_help, function (Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {

                $ans = $answer->getText();
                $this->say($ans .$this->user_name);

                switch ($answer->getValue()){
                    case "authors": 
                        $this->authors(); 
                        break;
                    case "hepatitis" :
                        $this->hepatitis(); 
                        break;
                    case "botcare" : 
                        $this->aboutApp(); 
                        break;
                    default : 
                        $this->say("Nah, You should choose between those option ". $this->user_name);

                }
            }
        });
    }

    public function askName()
    {
        $this->ask('Hello. I am Ella, the BotCare. What is your name?', function(Answer $answer) {
            //$bot->typesAndWaits(2);
            $this->say('Nice to meet you '. $answer->getText());
            $this->user_name = $answer->getText(); 

            $this->askHelp();

        });   
    }


       // Ask something else | Ask more ... 
       public function something_else(){
        
        $this->deja = 1;  

        $question_more = Question::create("Huh - Autre chose ".$this->user_name. " ?")
        ->fallback("Am sorry. Seems like I dont understand.")
        ->callbackId('ask_help')
        ->addButtons([
            Button::create('Yes')->value('yes'),
            Button::create('No')->value('no'),
        ]); 

        return $this->ask($question_more, function (Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {
                switch ($answer->getValue()){
                    case "yes": 
                        $this->askHelp(); 
                        break;
                    case "no" :
                        $this->insist(); 
                        break;
                    default : 
                        $this->say("Nah, You should choose between those option ". $this->user_name);

                }
            }
        }); 
    }


    // About us 
    public function aboutApp(){

        $this->say('Well. My name is Ella. I am your assistant in botCare. And am the one supposed to help you no matter what you need. ;). Hope it is okay now '. $this->user_name);

       $this->something_else(); 
    }

    // About Author 
    public function authors(){

        $this->say('Oww, The authors are four students from the University of Yaounde I: Sorelle Kana, Christian Evaga, Alford Njony and Ariane Djeupang. If you wanna know more about them, click her : <a href="https://www.php.net/manual/fr/control-structures.switch.php."></a> You have such questions   '. $this->user_name);

        $this->something_else(); 
    }

    // About Hepatits 
    public function hepatitis(){

       $question_hepatitis_type =  Question::create("So guy, which hepatitis are you interested in ? ")
        ->fallback('Unable to ask question')
        ->callbackId('hepatits')
        ->addButtons([
            Button::create('Hepatitis A')->value('VHA'),
            Button::create('Hepatitis B')->value('VHB'),
            Button::create('Hepatitis C')->value('VHC'),
            Button::create('Hepatitis D')->value('VHD'),
            Button::create('Hepatitis E')->value('VHE'),
        ]);
        
        return $this->ask($question_hepatitis_type, function (Answer $answer) {
            
            if ($answer->isInteractiveMessageReply()) {
                switch ($answer->getValue()){
                    case "VHA": 
                        $this->VHA(); 
                        break;
                    case "VH" :
                        $this->VH(); 
                        break;
                    case "VHC" : 
                        $this->VHC(); 
                        break;
                    case "VHD": 
                        $this->VHD();
                        break;
                    case "VHE": 
                        $this->VHE();
                        break;
                    default : 
                        $this->say("Damn ! You should choose bettween thos option". $this->user_name);
                }
            }
        });
      
    }


    // Insist : Au cas où l'utilisateur voudrait partir sans avoir rien fait d'important. 
    public function insist(){

        $question = Question::create("Sure you have nothing else to ask ".$this->user_name. " ? Et quelques infos sur l'hépatite, ça te dirait ?")
        ->fallback('Unable to ask question')
        ->callbackId('hepatits')
        ->addButtons([
            Button::create('OUI')->value('oui'),
            Button::create('NON')->value('non'),
        ]);

        return $this->ask($question, function (Answer $answer) {
            if ($answer->isInteractiveMessageReply()) {
                switch ($answer->getValue()){
                    case "oui": 
                        $this->hepatitis(); 
                        break;
                    case "non" :
                        $this->sayGoodbye(); 
                        break;
                    default : 
                        $this->say("Nah, You should choose between those option ". $this->user_name);

                }
            }
        }); 
    }

    // Say Goodbye 
    public function sayGoodbye(){
        $this->say("Revenez nous vite ".$this->user_name); 
    }

    // VHA 
    public function VHA(){

    }

    public function run()
    {
        $this->askName();
    }
}