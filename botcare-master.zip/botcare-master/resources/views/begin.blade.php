<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript" id="botcopy-embedder-d7lcfheammjct" class="botcopy-embedder-d7lcfheammjct"  data-botId="5f059559fcfa740008dd6750">
		var s = document.createElement('script'); 
		s.type = 'text/javascript'; s.async = true; 
		s.src = 'https://widget.botcopy.com/js/injection.js'; 
		document.getElementById('botcopy-embedder-d7lcfheammjct').appendChild(s);

		console.log(s); 
		
	</script>

	




	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Botcare - Begin</title>
	<link href="{{url('/botcare-css/bootstrap.min.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/datepicker3.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/styles.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/begin.css')}}" rel="stylesheet">
	<!link href="url{{('/botcare-css/newstyles.css')}}" rel="stylesheet">
	<!link href="url{{('/botcare-css/material-icons.min.css')}}" rel="stylesheet">
	<!--Custom Font-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar-collapse"><span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span></button>
				<a class="navbar-brand" href="#"><span>Bot</span>care</a>
				<ul class="nav navbar-top-links navbar-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<em class="fa fa-user"></em><span class=" fa fa-sort-down"></span>
						</a> 
						<ul class="dropdown-menu" >
							<li><a href="#" class="dropdown-item">Connexion</a></li>
							<li><a href="#" class="dropdown-item">Inscription</a></li>
							
						</ul>
					</li>
					<li class="">
						<select>
							<option>Fr</option>
							<option>Engl</option>
						</select>
					</li>
				</ul>
			</div>
		</div><!-- /.container-fluid -->
	</nav>
	<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		<br><br>
		<form role="search">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Search">
			</div>
		</form>
		<br>
		<ul class="nav menu">
			<li class="active"><a href="Begin.html"><em class="fa fa-home">&nbsp; Begin</em></a></li>
			<li><a href="/statistic"><em class="fa fa-bar-chart"></em>&nbsp; Statistiques</a></li>
			<li><a href="home"><em class="fa fa-download"></em>&nbsp; Export results</a></li>
			<li><a href="/faq"><em class="fa fa-lightbulb-o"></em>&nbsp; Le saviez vous ?</a></li>
			<li><a href="/help"><em class="fa fa-hand-o-right"></em>&nbsp; Help</a></li>
			<li><a href="/login"><em class="fa fa-power-off">&nbsp;</em> Logout</a></li>
		</ul>
	</div><!--/.sidebar-->

	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#">
					<em class="fa fa-home">&nbsp;</em>
				</a></li>
				<li class="active">Begin</li>
			</ol>
		</div><!--/.row-->
		
		<br><br><br><br><br>
        <div class="panel panel-container">
			<div class="row">
				<div class="col-md-6 border-right">
						<div class="panel panel-default">
							<div class="panel-heading">
									<!-- <em class="fa fa-user-circle">&nbsp;</em> -->
									<em class="fa fa-question-circle">&nbsp;</em><label>Recents questions</label>
								
								
							</div>
							<div class="panel-body">
								<div class="search-box">
      								<div class="input-wrapper">
      									<i class="fa fa-search"></i>
      									<input placeholder="Search questions" type="text">
      								</div>
								</div>
								<span>Recents Questions</span>
								<!hr>
								<div class="search-box">
									<ul>
										<li><a href="#" class="question-link">Qu'est ce qu'une hépatite ?</a></li>
										<li><a href="#" class="question-link">Quelles sont les causes de l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Comment dépiste-t-on l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Comment prévient-t-on l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Quelles sont les différents actions de lutte contre les hépatites ?</a></li>
										<li><a href="#" class="question-link">Quel est le nom de l'agent pathogène responsable des hépatites ?</a></li>
									</ul>
								</div>
							</div>
						</div>	
				</div>
				<div class="col-md-5 border-left">
						<div class="panel panel-default">
							<div class="panel-heading">
									<!-- <em class="fa fa-user-circle">&nbsp;</em> -->
									<em class="fa fa-question-circle">&nbsp;</em><label>Maladies récentes</label>
							</div>
							<div class="panel-body">
								<div class="search-box">
      								<div class="input-wrapper">
      									<i class="fa fa-search"></i>
      									<input placeholder="Search questions" type="text">
      								</div>
								</div>
								<span>Recents Questions</span>
								<!hr>
								<div class="search-box" id="questions">
									<ul>
										<li><a href="#" class="question-link">Qu'est ce qu'une hépatite ?</a></li>
										<li><a href="#" class="question-link">Quelles sont les causes de l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Comment dépiste-t-on l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Comment prévient-t-on l'hépatite ?</a></li>
										<li><a href="#" class="question-link">Quelles sont les différents actions de lutte contre les hépatites ?</a></li>
										<li><a href="#" class="question-link">Quel est le nom de l'agent pathogène responsable des hépatites ?</a></li>
									</ul>
								</div>
							</div>
						</div>	
				</div>	
        	</div>
		</div>
	</div>
	<script src="{{url('botcare-js/jquery-1.11.1.min.js')}}"></script>
	<script src="{{url('botcare-js/bootstrap.min.js')}}"></script>
	<script src="{{url('botcare-js/chart.min.js')}}"></script>
	<script src="{{url('botcare-js/chart-data.js')}}"></script>
	<script src="{{url('botcare-js/easypiechart.js')}}"></script>
	<script src="{{url('botcare-js/easypiechart-data.js')}}"></script>
	<script src="{{url('botcare-js/bootstrap-datepicker.js')}}"></script>
	<script src="{{url('botcare-js/custom.js')}}"></script>
	<script src="{{url('botcare-js/newJS.js')}}"></script>
	<script src="{{url('/js/app.js')}}"></script>
	<script>
		window.onload = function () {
			var chart1 = document.getElementById("line-chart").getContext("2d");
			window.myLine = new Chart(chart1).Line(lineChartData, {
			responsive: true,
			scaleLineColor: "rgba(0,0,0,.2)",
			scaleGridLineColor: "rgba(0,0,0,.05)",
			scaleFontColor: "#c5c7cc"
			});
		};

		// CAll the dropdown 
		$('.dropdown-toggle').dropdown()

		
		var parent = document.getElementById("botcopy-react-root"); 
		var test2 = document.getElementById("botcopy-widget-root"); 
		var test = document.getElementsByClassName("botcopy-embedder-d7lcfheammjct"); 
		console.log(test2); 

	</script>
		
</body>
</html>