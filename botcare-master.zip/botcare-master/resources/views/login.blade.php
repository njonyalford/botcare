<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Botcare - Login</title>
	<link href="{{url('/botcare-css/bootstrap.min.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/font-awesome.min.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/datepicker3.css')}}" rel="stylesheet">
	<link href="{{url('/botcare-css/styles.css')}}" rel="stylesheet">
	<!link href="url{{('/botcare-css/newstyles.css')}}" rel="stylesheet">
	<!link href="url{{('/botcare-css/material-icons.min.css')}}" rel="stylesheet">
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel Newpanel-default">
				<div class="Panel-heading">Log in</div>
				<div class="panel-body">
					<form role="form">
						<fieldset>
							<div class="form-group">
								<!input class="form-control" placeholder="E-mail" name="email" type="email" autofocus="">
								<input class="form-control" placeholder="Username" name="username" type="Text" value="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="password" type="password" value="">
							</div>
							<div class="checkbox">
								<label>
									<input name="remember" type="checkbox" value="Remember Me">Remember Me
								</label>
							</div>
							<a href="Begin.html" class="btn btn-primary">Login</a><label> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;click</label><a href="registration.html" > here</a><label>&nbsp;to register</label></fieldset>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	

	<script src="{{url('js/jquery-1.11.1.min.js')}}"></script>
	<script src="{{url('js/bootstrap.min.js')}}"></script>
</body>
</html>
