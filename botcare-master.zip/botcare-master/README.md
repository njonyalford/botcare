<p align="center"><img height="188" width="198" src="https://botman.io/img/botman.png"></p>
<h1 align="center">BotCare</h1>

## A propos BotCare

BotCare est une application de question-answering dans le but de repondre à certaines préoccupations concernant les maladies tel que hépatites , ... 
Mode de contagion, traitement, prévention, autant de questions qui inquiétent le commun des êtres humains.

BotCare est accompagné d'un bot "Ella" qui se charge de rpeondre à toutes les préoccupations.

## Comment demarrer BotCare ?
Après avoir télécharger le dépot, placer vous à l'intérieur de celui-ci et lancez la commande "php artisan serve" dans votre terminal (sur uBuntu) ou invite de commande (sur windows). 

L'url de départ est 127.0.0.1:numero_port/home


## Comment discuter avec Ella?
Tapez "Hello" sur la barre de saisie dans le tchat du home. Et ça y est, vous pouvez discutez avec "Ella". 


## Support the development
**Do you like this project? Support it by donating**
Ecrivez à l'adresse : kanasorella@gmail.com




